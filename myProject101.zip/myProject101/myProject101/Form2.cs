﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace myProject101
{
    public partial class Form2 : Form
    
    {
        public Form2()
        {
            InitializeComponent();
         
            MaterialSkin.MaterialSkinManager skinManager = MaterialSkin.MaterialSkinManager.Instance;
           
            skinManager.Theme = MaterialSkin.MaterialSkinManager.Themes.LIGHT;
            skinManager.ColorScheme = new MaterialSkin.ColorScheme(MaterialSkin.Primary.Cyan600, //Green600
            MaterialSkin.Primary.BlueGrey900, MaterialSkin.Primary.BlueGrey500, MaterialSkin.Accent.Orange700, MaterialSkin.TextShade.WHITE);
         //  FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;

            ControlBox = false;
        }


        private void Form2_Load(object sender, EventArgs e)
        {
            
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void materialRaisedButton1_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField2_Click(object sender, EventArgs e)
        {

        }

        private void materialSingleLineTextField1_Click(object sender, EventArgs e)
        {
            
        }

        private void Login_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Successfully Log In" , "Log In" , MessageBoxButtons.OK,MessageBoxIcon.Information);
            Mainmenu Mainmenu = new Mainmenu();
            Mainmenu.Show();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            materialSingleLineTextField1.Clear();
            materialSingleLineTextField2.Clear();
        }

        private void label2_Click(object sender, EventArgs e)
        {
            label2.Text = "Login";
        }
    }
}
